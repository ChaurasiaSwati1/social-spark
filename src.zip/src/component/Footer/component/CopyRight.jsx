const CopyRight = () => {
  return (
    <>
      <div className="py-3 bg-dark">
      <div className="container-md container-fluid">
        <p className="mb-0 text-center text-dark-yellow fw-700"><small>© 2025 All right reserved by Social Spark - Noida</small></p>
      </div>
    </div>
    </>
  );
};

export default CopyRight;
