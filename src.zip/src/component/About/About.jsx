import { NavLink } from "react-router-dom";

const About = () => {
  return (
    <>
        <div className="container">
            <div className="row align-items-center">
                <div className="col-sm-12 col">
                <h2 className="text-yellow m-0">About</h2>
                </div>
            </div>
        </div>
    </>
  );
};

export default About;